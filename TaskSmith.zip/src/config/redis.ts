import { Queue } from "bullmq";
import IORedis from 'ioredis';

import { createClient } from 'redis';

// const client = createClient({
//     username: 'default',
//     password: '6CwNVcym1ZXo4QtgSX1E7432CYtTNJqo',
//     socket: {
//         host: 'redis-15848.c232.us-east-1-2.ec2.redns.redis-cloud.com',
//         port: 15848
//     }
// });

const connection = new IORedis({
  port: 15848, // Redis port
  host: 'redis-15848.c232.us-east-1-2.ec2.redns.redis-cloud.com', // Redis host
  username: "default", // needs Redis >= 6
  password: '6CwNVcym1ZXo4QtgSX1E7432CYtTNJqo',
  db: 0, // Defaults to 0
});

connection.on('error', err => console.log('Redis Client Error', err));

// async() => await client.connect();

 async () => await connection.set('foo', 'bar');

async() => {
    const result = await connection.get('foo');
    console.log(result);  // >>> bar
}




export const myQueue = new Queue('taskQueue', { connection });


