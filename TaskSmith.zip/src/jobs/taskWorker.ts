import { Job, Worker } from "bullmq";
import { myQueue } from "../config/redis";
import { updateTaskStatus } from "../models/taskModel";

const worker = new Worker('taskQueue', async (job:Job) =>{
    
    const { taskId } = job.data;

    await updateTaskStatus(taskId, 'pending');
    console.log("Task status changed to 'pending'");

    await new Promise(res => setTimeout(res, 3000));

    await updateTaskStatus(taskId, 'completed');
    console.log("Task status changed to 'completed'");
});